import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import time
import os

class TxtPublisher(Node):
    def __init__(self):
        super().__init__('txt_publisher')
        self.publisher_ = self.create_publisher(String, 'txt_data', 10)
        self.timer = self.create_timer(1.0, self.publish_txt_data)  # Publish every second
        self.txt_file = '/home/user/CoolTermLinux64Bit/data1.txt'  # Path to the .txt file
        self.file_pointer = None
        self.last_position = 0  # Track the last position in the file
        
        try:
            # Open the file in read mode (we will continuously monitor it for new data)
            self.file_pointer = open(self.txt_file, 'r')
        except FileNotFoundError:
            self.get_logger().error(f"File not found: {self.txt_file}")
            rclpy.shutdown()

    def publish_txt_data(self):
        # Move to the end of the file and keep reading new data
        self.file_pointer.seek(self.last_position)
        line = self.file_pointer.readline()
        
        if line:
            msg = String()
            msg.data = line.strip()  # Publish the IMU data line
            self.publisher_.publish(msg)
            self.get_logger().info(f'Publishing: "{msg.data}"')
            # Update the last known position after reading
            self.last_position = self.file_pointer.tell()
        else:
            # If no new data, wait briefly and try again (file is being updated by another process)
            time.sleep(0.1)

def main(args=None):
    rclpy.init(args=args)
    node = TxtPublisher()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

